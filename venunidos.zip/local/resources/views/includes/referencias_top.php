<meta charset="utf-8"/>
<meta content="IE=edge" http-equiv="X-UA-Compatible"/>
<meta content="0" http-equiv="Expires"/>
<meta content="0" http-equiv="Last-Modified"/>
<meta content="no-cache, mustrevalidate" http-equiv="Cache-Control"/>
<meta content="no-cache" http-equiv="Pragma"/>
<!-- Tell the browser to be responsive to screen width -->
<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport"/>
<!-- Bootstrap 3.3.7 -->
<link href="/venunidos/local/resources/views/bootstrap/css/bootstrap.min.css" rel="stylesheet"/>
<!-- Font Awesome -->
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css" rel="stylesheet"/>
<!-- Ionicons -->
<link href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css" rel="stylesheet"/>
<!-- Theme style -->
<link href="/venunidos/local/resources/views/dist/css/AdminLTE.min.css" rel="stylesheet"/>
<!-- AdminLTE Skins. Choose a skin from the css/skins
       folder instead of downloading all of them to reduce the load. -->
<link href="/venunidos/local/resources/views/dist/css/skins/_all-skins.min.css" rel="stylesheet"/>
<link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic" rel="stylesheet"/>
<link href="/venunidos/local/resources/views/css/styles.css" rel="stylesheet" type="text/css"/>
