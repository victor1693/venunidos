            <div class="col-xs-12 sp " style="position: fixed;z-index: 1;">
                <div class="col-lg-2 col-sm-0">
                    <div style="color: #f8f8f8;background-color: #f8f8f8;height: 5px;">
                        a
                    </div>
                </div>
                <nav class="navbar navbar-default ">
                    <div class="container-fluid">
                        <div class="navbar-header">
                            <button class="navbar-toggle collapsed" data-target="#navbar7" data-toggle="collapse" type="button">
                                <span class="sr-only">
                                    Toggle navigation
                                </span>
                                <span class="icon-bar">
                                </span>
                                <span class="icon-bar">
                                </span>
                                <span class="icon-bar">
                                </span>
                            </button>
                        </div>
                        <div class="navbar-collapse collapse " id="navbar7">
                            <ul class="nav navbar-nav " id="menu-subbarra">                                 
                                  <li>
                                    <a href="/venunidos/dash">
                                        Inicio
                                    </a>
                                </li>
                                <li>
                                    <a href="/venunidos/gnoticias">
                                        Noticias
                                    </a>
                                </li>
                                
                            </ul>
                        </div>
                        <!--/.nav-collapse -->
                    </div>
                    <!--/.container-fluid -->
                </nav>
            </div>