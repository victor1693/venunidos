<div class="col-sm-4 col-lg-2 sp" style="padding-top: 19px;">
                    <div class="box box-solid">
                     
                        <div class="box-header with-border">
                            <h3 class="box-title">
                                Opciones
                            </h3>
                            
                        </div>
                        <!-- /.box-header -->
                        <div class="box-body no-padding" style="">

                           <ul class="nav nav-pills nav-stacked">
                                <li>
                                    <a href="configuracion">
                                        <i class="fa fa-circle-o text-green">
                                        </i>
                                        Perfil
                                    </a>
                                </li>
                                  <li>
                                    <a href="privacidad">
                                        <i class="fa fa-circle-o text-green">
                                        </i>
                                        Privacidad
                                    </a>
                                </li>
                                <li>
                                    <a href="seguridad">
                                        <i class="fa fa-circle-o text-green">
                                        </i>
                                        Seguridad
                                    </a>
                                    </li>
                                   <!-- <li>
                                     <a href="alertas">
                                        <i class="fa fa-circle-o text-yellow">
                                        </i>
                                        Notificaciones 
                                    </a>
                                    </li>-->
                                                             
                            </ul>
                        </div>
                        <!-- /.box-body -->
                    </div>
                </div>